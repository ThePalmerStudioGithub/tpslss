﻿using DiscordRPC;
using DiscordRPC.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Control_Panel
{
	public partial class Form1 : Form
	{
		public Form1()

		{
			InitializeComponent();
		}
		public DiscordRpcClient client;
		void InitializeRPC()
		{
			/*
			Create a Discord client
			NOTE: 	If you are using Unity3D, you must use the full constructor and define
					 the pipe connection.
			*/
			client = new DiscordRpcClient("782873960932835338");

			//Set the logger
			client.Logger = new ConsoleLogger() { Level = LogLevel.Warning };

			//Subscribe to events
			client.OnReady += (sender, e) =>
			{
				Console.WriteLine("Received Ready from user {0}", e.User.Username);
			};

			client.OnPresenceUpdate += (sender, e) =>
			{
				Console.WriteLine("Received Update! {0}", e.Presence);
			};

			//Connect to the RPC
			client.Initialize();

			//Set the rich presence
			//Call this as many times as you want and anywhere in your code.
			client.SetPresence(new RichPresence()
			{
				Details = "In Control Panel",
				State = "Viewing window",
				Assets = new Assets()
				{
					LargeImageKey = "live",
					LargeImageText = "TPSLSS Control Panel",
					SmallImageKey = "nothing",
					SmallImageText = "TPSLSS"
				}
			});
		}
		private void Form1_Load(object sender, EventArgs e)
		{
			

		}

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
			if(checkBox1.Checked == true)
            {
				InitializeRPC();

            }
			if(checkBox1.Checked == false)
            {
				client.Deinitialize();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
			if(e.KeyCode == Keys.Enter)
            {
				client.UpdateDetails(textBox1.Text);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
			if(e.KeyCode == Keys.Enter)
            {
				client.UpdateState(textBox2.Text);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
			client.UpdateDetails("In OBS");
			client.UpdateState("Waiting...");
			System.Diagnostics.Process.Start(@"C:\Users\Blaine Palmer\Desktop\Recording");
		
        }

        private void button2_Click(object sender, EventArgs e)
        {
			client.UpdateDetails("In GIMP");
			client.UpdateState("Making a thumbnail");
			System.Diagnostics.Process.Start(@"E:\Program Files\GIMP 2\bin\gimp-2.10.exe");
        }

        private void button3_Click(object sender, EventArgs e)
        {
			System.Diagnostics.Process.Start("https://studio.youtube.com/?ref=tpslss");
        }

        private void button4_Click(object sender, EventArgs e)
        {
			

			client.SetPresence(new RichPresence()
			{
				Details = "In Control Panel",
				State = "Ready",
				Assets = new Assets()
				{
					LargeImageKey = "live",
					LargeImageText = "TPSLSS",
					SmallImageKey = "check",
					SmallImageText = "Ready"
				}
			});
		}

        private void button5_Click(object sender, EventArgs e)
        {
			
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
			client.SetPresence(new RichPresence()
			{
				Details = "Live now!",
				State = "Streaming",
				Timestamps = Timestamps.Now,
				Assets = new Assets()
				{
					LargeImageKey = "live",
					LargeImageText = "TPSLSS",
					SmallImageKey = "clapping",
					SmallImageText = "Live"
				}
			});
		}

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
			DiscordManagement managementweb = new DiscordManagement();
			managementweb.Show();
        }
    }
    }

